dbPassword = 'mongodb+srv://lucky:lucky@cluster0-ujbqe.mongodb.net/test?retryWrites=true&w=majority';

module.exports = {
    mongoURI: dbPassword
};
